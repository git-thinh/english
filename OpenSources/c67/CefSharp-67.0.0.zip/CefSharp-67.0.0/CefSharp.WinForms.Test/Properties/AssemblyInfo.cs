﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.WinForms.Test")]
[assembly: AssemblyCompany("Anthony Taranto")]
[assembly: AssemblyProduct("CefSharp.Example")]
[assembly: AssemblyCopyright("Copyright © 2013")]

[assembly: AssemblyVersion("1.25.2.*")]
[assembly: ComVisible(false)]
